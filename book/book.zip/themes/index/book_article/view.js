function smallImg(s){
  		return s+".100x100.jpg";
}
function reply_text(nick,con){
	return "回复@"+nick+":"+con;
}
var cm = new Vue({
  el: '#page-comment-list',
  data: {
  	a:"asd",
    data:[]
    
  },
 
  computed:{
  	
  }
})

 

