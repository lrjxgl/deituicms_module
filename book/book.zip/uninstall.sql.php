<?php
$content=<<<eof
drop table sky_mod_book ;
drop table sky_mod_book_article ;
drop table sky_mod_book_article_comment ;
drop table sky_mod_book_article_data ;
drop table sky_mod_book_article_log ;
drop table sky_mod_book_comment ;
drop table sky_mod_book_note ;
drop table sky_mod_book_order ;

eof;
?>