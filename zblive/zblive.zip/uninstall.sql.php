<?php
$content=<<<eof
drop table sky_mod_zblive ;
drop table sky_mod_zblive_config ;
drop table sky_mod_zblive_hoster ;
drop table sky_mod_zblive_hoster_apply ;
drop table sky_mod_zblive_liveaccess ;
drop table sky_mod_zblive_msg ;
drop table sky_mod_zblive_product ;

eof;
?>