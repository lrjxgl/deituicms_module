<?php
$content=<<<eof
drop table sky_mod_zhuli ;
drop table sky_mod_zhuli_data ;
drop table sky_mod_zhuli_go ;
drop table sky_mod_zhuli_join ;
drop table sky_mod_zhuli_order ;
drop table sky_mod_zhuli_shaidan ;

eof;
?>