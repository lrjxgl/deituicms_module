<?php
define("ZHULI_MODEL_ID",13);
?>