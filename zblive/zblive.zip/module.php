<?php
define("ZBLIVE_MODEL_ID",18);
define("MODULENAME","zblive");
define("BACKHOST","http://zbtest.deitui.com/skylive");
if(!defined("OC_SSID")){
	define("OC_SSID",session_id());
}
?>