<?php
$content=<<<eof
drop table sky_mod_exam ;
drop table sky_mod_exam_answer ;
drop table sky_mod_exam_ask ;
drop table sky_mod_exam_topic ;

eof;
?>